#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/wait.h>

struct cs1550_sem {
	int value;
	void *lock;
	struct node* head;
	struct node* tail;
};

void sem_init(struct cs1550_sem *sem, int value){
	syscall(441, sem, value);
}

void sem_down(struct cs1550_sem *sem){
	syscall(442, sem);
}

void sem_up(struct cs1550_sem *sem){
	syscall(443, sem);
}

//semaphore for controlling access to the buffer
struct cs1550_sem *mutex;

//semaphore for counting filled spaces in the buffer
struct cs1550_sem *full;

//semaphore for counting available spaces in the buffer
struct cs1550_sem *empty;

int main(int argc, char *argv[]) {

	//check command line arguments
	if(argc != 4){
		fprintf(stderr, "Usage: %s <number of producers> <number of consumers> <buffer size>\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	//parse arguments
	int num_producers = atoi(argv[1]);
	int num_consumers = atoi(argv[2]);
	int buffer_size = atoi(argv[3]);

	//allocate shared memory for semaphore
	struct cs1550_sem* sem_mem = (struct cs1550_sem *)mmap(NULL, sizeof(struct cs1550_sem)*3, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, 0, 0);

	//allocate shared memory for producers and consumers
	int* shared_mem = (int *)mmap(NULL, (buffer_size+2)*sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, 0, 0);


	int curr_producer = 0;
	int curr_consumer = 0;

	//initialize semaphores
	struct cs1550_sem* empty = sem_mem;
	sem_init(empty, buffer_size);

	struct cs1550_sem* full = sem_mem + 1;
	sem_init(full, 0);

	struct cs1550_sem* mutex = sem_mem + 2;
	sem_init(mutex, 1);

	//initalize to track the current produced and consumed item
	int* curr_produced = shared_mem;
	*curr_produced = 0;

	int* curr_consumed =shared_mem + 1;
	*curr_consumed;

	//beginning of shared buffer in memory
	int* buffer_ptr = shared_mem + 2;

	int i;
	for(i = 0; i < num_producers; i++){

		if(fork() == 0){
			int item;
			while(1){
				sem_down(empty);

				sem_down(mutex);

				item = *curr_produced;
				buffer_ptr[*curr_produced % buffer_size] = item;
				printf("Producer: %c Produced: %d\n", (i+65), item);
				*curr_produced+=1;

				sem_up(mutex);
				sem_up(full);
			}
		}

	}

	for(i = 0; i < num_consumers; i++){

		if(fork() == 0){
			int item;
			while(1){

				sem_down(full);
				sem_down(mutex);

				item = buffer_ptr[*curr_consumed % buffer_size];
				printf("Consumer: %c Consumed: %d\n", (i+65), item);
				*curr_consumed+=1;

				sem_up(mutex);
				sem_up(empty);
			}
		}

	}

	//parent process waits here
	int status;
	wait(&status);

	return 0;
}
