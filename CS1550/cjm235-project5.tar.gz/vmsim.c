#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
typedef struct {
    int frame;
    int dirtyBit;
    int referenceBit;
    int validBit;
    int time;
    int counter;
} PageTableEntry;

typedef struct{
    int location;
    int address;
    int nextAccess;
    struct Node* next;
}Node;

typedef struct {
    PageTableEntry leaf[1024];
} PageTable;

typedef struct {
    PageTable *pageTable[512];
} Root;

typedef struct {
    int head;
    int tail;
    PageTableEntry **entries;
    int size;
} Queue;

typedef struct{
    Node *head;
    Node *tail;
}Bucket;

typedef struct {
	Bucket buckets[512];
}HashTable;

void opt(int numFrames, Root *root, char *traceFile);
void lru(int numFrames, Root *root, char *traceFile);
void clock(int numFrames, Root *root, char *traceFile);

int main(int argc, char *argv[]) {
    if (argc != 6) {
        fprintf(stderr, "Usage: %s -n <numframes> -a <opt|clock|lru> <tracefile>\n", argv[0]);
        return 1;
    }

    int numFrames = atoi(argv[2]);
    const char *algorithm = argv[4];
    const char *traceFile = argv[5];

    PageTable pageTable;

    // allocate space for page table
    Root *root = (Root *)malloc(sizeof(Root));

    for (int i = 0; i < 512; i++) {
        root->pageTable[i] = NULL;
    }

    // run appropriate algorithm
    if (strcmp(algorithm, "opt") == 0) {
        opt(numFrames, root, traceFile);
    } else if (strcmp(algorithm, "clock") == 0) {
        clock(numFrames, root, traceFile);
    } else if (strcmp(algorithm, "lru") == 0) {
        lru(numFrames, root, traceFile);
    } else {
        printf("Invalid argument.\n");
        exit(EXIT_FAILURE);
    }

    return EXIT_SUCCESS;
}

void clock(int numFrames, Root *root, char *traceFile) {
    Queue *queue = (Queue *)malloc(sizeof(Queue));
    queue->entries = (PageTableEntry **)malloc(numFrames * sizeof(PageTableEntry));
    queue->head = -1;
    queue->tail = -1;
    queue->size = numFrames;

    int memAccesses = 0;
    int pageFaults = 0;
    int writes = 0;
    int leaves = 0;
    int currFrame = 0;

    char type;
    int address, size;
    int physicalMemory[numFrames];
    FILE *file = fopen(traceFile, "r");
    if (file == NULL) {
        perror("Error opening file\n");
        exit(EXIT_FAILURE);
    }

    while (fscanf(file, "%c %x, %d\n", &type, &address, &size) != EOF) {
        if (size != 0) {
            memAccesses++;

            int rootAddress = (address & 0xFF800000) >> 23;
            int leafAddress = (address & 0x007FE000) >> 13;
	    int offset = address & 0x00001FFF;

            if (root->pageTable[rootAddress] == NULL) {
                root->pageTable[rootAddress] = (PageTable *)malloc(sizeof(PageTable));
                for (int i = 0; i < 1024; i++) {
                    root->pageTable[rootAddress]->leaf[i].counter = i + (rootAddress * 1024);
                    root->pageTable[rootAddress]->leaf[i].time = 0;
                    root->pageTable[rootAddress]->leaf[i].dirtyBit = 0;
                    root->pageTable[rootAddress]->leaf[i].referenceBit = 0;
                    root->pageTable[rootAddress]->leaf[i].validBit = 0;
                    root->pageTable[rootAddress]->leaf[i].frame = -1;
                }
            }

            PageTableEntry *pte = &root->pageTable[rootAddress]->leaf[leafAddress];
            pte->referenceBit = 1;
	    pte->time = memAccesses;

            if (type == 'S' || type == 'M') {
                pte->dirtyBit = 1;
            }

            if (pte->validBit) {
                printf("0x%08X hit\n", address);
            } else {
                pageFaults++;
                if (currFrame < (numFrames - 1)) {
                    printf("Page fault no eviction 0x%08X\n", address);
                    physicalMemory[currFrame] = pte->counter;
                    pte->validBit = 1;
                    pte->frame = currFrame;
                    currFrame++;

                    if (queue->head == -1) {
                        queue->head = 0;
                        queue->tail = 0;
                        queue->entries[queue->tail] = pte;
                    } else {
                        queue->tail = (queue->tail + 1) % queue->size;
                        queue->entries[queue->tail] = pte;
                    }
                } else {
                    printf("Page fault eviction 0x%08X\n", address);
                    while (queue->entries[queue->head]->referenceBit) {
                        queue->entries[queue->head]->referenceBit = 0;
                        queue->tail = (queue->tail + 1) % queue->size;
                        queue->entries[queue->tail] = queue->entries[queue->head];
                        queue->head = (queue->head + 1) % queue->size;
                    }
                    PageTableEntry *evict = queue->entries[queue->head];
                    if (evict->dirtyBit) {
                        printf("Page fault evict dirty 0x%08X\n", address);
                        writes++;
                    } else {
                        printf("Page fault evict clean 0x%08X\n", address);
                    }
			queue->entries[queue->head] = pte;
			physicalMemory[evict->frame] = pte->counter;
			pte->validBit = 1;
			evict->dirtyBit = 0;
			evict->referenceBit = 0;
			evict->validBit = 0;
			evict->frame = -1;
                }
            }
        }
    }

    fclose(file);

    for (int i = 0; i < 512; i++) {
        if (root->pageTable[i] != NULL) {
            leaves++;
        }
    }

    printf("Algorithm: clock\n");
    printf("Number of frames: %d\n", numFrames);
    printf("Total memory access: %d\n", memAccesses);
    printf("Total page faults: %d\n", pageFaults);
    printf("Total writes to disk: %d\n", writes);
    printf("Number of page table leaves: %d\n", leaves);
    printf("Total size of page table: %lu\n", (leaves * (sizeof(PageTableEntry) * 1024)) + sizeof(Root));

    // Free allocated memory
    free(queue->entries);
    free(queue);
}

void lru(int numFrames, Root *root, char *traceFile) {
    Queue *queue = (Queue *)malloc(sizeof(Queue));
    queue->entries = (PageTableEntry **)malloc(numFrames * sizeof(PageTableEntry *));
    queue->head = -1;
    queue->tail = -1;
    queue->size = numFrames;

    int memAccesses = 0;
    int pageFaults = 0;
    int writes = 0;
    int leaves = 0;
    int currFrame = 0;

    char type;
    int address, size;
    int physicalMemory[numFrames];

    FILE *file = fopen(traceFile, "r");
    if (file == NULL) {
        perror("Error opening file\n");
        exit(EXIT_FAILURE);
    }

    while (fscanf(file, "%c %x, %d\n", &type, &address, &size) != EOF) {
        if (size != 0) {
            memAccesses++;

            int rootAddress = (address & 0xFF800000) >> 23;
            int leafAddress = (address & 0x007FE000) >> 13;
            int offset = address & 0x00001FFF;

            if (root->pageTable[rootAddress] == NULL) {
                root->pageTable[rootAddress] = (PageTable *)malloc(sizeof(PageTable));
                for (int i = 0; i < 1024; i++) {
                    root->pageTable[rootAddress]->leaf[i].counter = i + (rootAddress * 1024);
                    root->pageTable[rootAddress]->leaf[i].time = 0;
                    root->pageTable[rootAddress]->leaf[i].dirtyBit = 0;
                    root->pageTable[rootAddress]->leaf[i].referenceBit = 0;
                    root->pageTable[rootAddress]->leaf[i].validBit = 0;
                    root->pageTable[rootAddress]->leaf[i].frame = -1;
                }
            }

            PageTableEntry *pte = &root->pageTable[rootAddress]->leaf[leafAddress];
            pte->referenceBit = 1;
            pte->time = memAccesses;

            if (type == 'S' || type == 'M') {
                pte->dirtyBit = 1;
            }

            if (pte->validBit) {
                printf("0x%08X hit\n", address);
            } else {
                pageFaults++;
                if (currFrame < (numFrames - 1)) {
                    printf("Page fault no eviction 0x%08X\n", address);
                    physicalMemory[currFrame] = pte->counter;
                    pte->validBit = 1;
                    pte->frame = currFrame;
                    currFrame++;

                    if (queue->head == -1) {
                        queue->head = 0;
                        queue->tail = 0;
                        queue->entries[queue->tail] = pte;
                    } else {
                        queue->tail = (queue->tail + 1) % queue->size;
                        queue->entries[queue->tail] = pte;
                    }
                } else {
                    printf("Page fault eviction 0x%08X\n", address);
                    PageTableEntry *evict = queue->entries[queue->head];
                    if (evict->dirtyBit) {
                        printf("Page fault - evict dirty 0x%08X\n", address);
                        writes++;
                    } else {
                        printf("Page fault - evict clean 0x%08X\n", address);
                    }

                    queue->head = (queue->head + 1) % queue->size;
                    queue->tail = (queue->tail + 1) % queue->size;
                    queue->entries[queue->tail] = pte;

                    physicalMemory[evict->frame] = pte->counter;
                    pte->frame = evict->frame;
                    pte->validBit = 1;
                    evict->dirtyBit = 0;
                    evict->referenceBit = 0;
                    evict->validBit = 0;
                    evict->frame = -1;
                }
            }
        }
    }

    fclose(file);

    for (int i = 0; i < 512; i++) {
        if (root->pageTable[i] != NULL) {
            leaves++;
        }
    }

    printf("Algorithm: LRU\n");
    printf("Number of frames: %d\n", numFrames);
    printf("Total memory access: %d\n", memAccesses);
    printf("Total page faults: %d\n", pageFaults);
    printf("Total writes to disk: %d\n", writes);
    printf("Number of page table leaves: %d\n", leaves);
    printf("Total size of page table: %d\n", (leaves * (sizeof(PageTableEntry) * 1024)) + sizeof(Root));
}

int extractBits(int address, int mask, int shift){
    return (address & mask) >> shift;
}

int hash(int value){
    return value % 512;
}
int hashParse(FILE *file,HashTable *table){

	int count=0;
	unsigned int address;
	int size;
	char event;
	char buf[256];
	while(fgets(buf,256,file)!= NULL) {
		if(buf[0] != '='){
			sscanf(buf "%c %x, %d", &event, &address, &size);
            		insertIntoHashTable(&table,address,count);
            		count++;
    		}else{
			continue;
		}
 	}
}

// Function to insert an address into the hash table
void insertIntoHashTable(HashTable* hashTable, unsigned int address,int count) {

    int  rootAddress = extractBits(address,0xFF800000,23);
    int index = hash(rootAddress);
	printf("insert hash table node.\n");
    Node* newNode = (Node*) malloc(sizeof(Node));
    if (newNode == NULL) {
        fprintf(stderr, "Memory allocation failed for hash table node.\n");
        exit(EXIT_FAILURE);
    }



    newNode->location=count;
    newNode->address = rootAddress;
    newNode->next = NULL;

    if (hashTable->buckets[index].head == NULL) {
       hashTable->buckets[index].head =  newNode;
    }
    else {
       (hashTable->buckets[index].tail)->next = newNode;
    }
    hashTable->buckets[index].tail = newNode;

}

void removeFromHashTable(HashTable* hashTable, unsigned int address) {
    unsigned int index = hash(address);
    // Ensure that the index is valid
        Node* current = hashTable->buckets[index].head;
        Node* prev = NULL;
    while(current != NULL && current->address != address){
        prev = current;
        current = current->next;
    }
        // Traverse the linked list until the last node
        if (current == NULL) {
            printf("removeFromHashTable Unexpected NULL entry found on hash table..\n");
            exit(EXIT_FAILURE);
        }
    if(prev == NULL){
        hashTable->buckets[index].head = current->next;
    }else{
        prev->next = current->next;
    }
        free (current);
}

void opt(int numFrames, Root *root, char *traceFile) {
    Queue *queue = (Queue *)malloc(sizeof(Queue));
    queue->entries = (PageTableEntry **)malloc(numFrames * sizeof(PageTableEntry *));
    queue->head = -1;
    queue->tail = -1;
    queue->size = numFrames;

    int memAccesses = 0;
    int pageFaults = 0;
    int writes = 0;
    int leaves = 0;
	int currFrame = 0;

    char type;
    int address, size;

    int physicalMemory[numFrames];
    HashTable futureAccessTable;

    for(int i = 0; i < 512; i++){
        futureAccessTable.buckets[i].head = NULL;
        futureAccessTable.buckets[i].tail = NULL;
    }

    FILE *file = fopen(traceFile, "r");
    if (file == NULL) {
        perror("Error opening file\n");
        exit(EXIT_FAILURE);
    }

    hashParse(file, &futureAccessTable);
    fseek(file, 0, SEEK_SET);

    while (fscanf(file, "%c %x, %d\n", &type, &address, &size) != EOF) {
        if (size != 0) {
            memAccesses++;

            int rootAddress = extractBits(address, 0xFF800000, 23 );
            int leafAddress = extractBits(address, 0x007FE000, 13);
            int index = hash(rootAddress);
            int nextAccess = INT_MAX;
            int offset = address & 0x00001FFF;

            Node* current = futureAccessTable.buckets[index].head;
            while(current != NULL){
                if(current->address == rootAddress){
                    nextAccess = current->nextAccess;
                    break;
                }
                current = current->next;
            }

            if (root->pageTable[rootAddress] == NULL) {
                root->pageTable[rootAddress] = (PageTable *)malloc(sizeof(PageTable));
                for (int i = 0; i < 1024; i++) {
                    root->pageTable[rootAddress]->leaf[i].counter = i + (rootAddress * 1024);
                    root->pageTable[rootAddress]->leaf[i].time = 0;
                    root->pageTable[rootAddress]->leaf[i].dirtyBit = 0;
                    root->pageTable[rootAddress]->leaf[i].referenceBit = 0;
                    root->pageTable[rootAddress]->leaf[i].validBit = 0;
                    root->pageTable[rootAddress]->leaf[i].frame = -1;
                }
            }

            PageTableEntry *pte = &root->pageTable[rootAddress]->leaf[leafAddress];
            pte->referenceBit = 1;
            pte->time = memAccesses;

            if (type == 'S' || type == 'M') {
                pte->dirtyBit = 1;
            }

            if (pte->validBit) {
                printf("0x%08X hit\n", address);
            } else {
                pageFaults++;
                if (currFrame < (numFrames - 1)) {
                    printf("Page fault no eviction 0x%08X\n", address);
                    physicalMemory[currFrame] = pte->counter;
                    pte->validBit = 1;
                    pte->frame = currFrame;
                    currFrame++;

                    if (queue->head == -1) {
                        queue->head = 0;
                        queue->tail = 0;
                        queue->entries[queue->tail] = pte;
                    } else {
                        queue->tail = (queue->tail + 1) % queue->size;
                        queue->entries[queue->tail] = pte;
                    }
                } else {
                    printf("Page fault eviction 0x%08X\n", address);
                    PageTableEntry *evict = NULL;
                    int maxDistance = -1;

                    for(int i = 0; i < queue->size; i++){
                        int evictPage = queue->entries[i]->counter/ 1024;
                        int evictLeaf = queue->entries[i]->counter % 1024;

                        Node* evictNode = &futureAccessTable.buckets[index].head;
                        while(evictNode != NULL){
                            if(evictNode->address == evictPage){
                                if(evictNode->nextAccess > maxDistance){
                                    maxDistance = evictNode->nextAccess;
                                    evict = queue->entries[i];
                                }
                                break;
                            }
                            evictNode = evictNode->next;
                        }
                    }


                    if (evict->dirtyBit) {
                        printf("Page fault - evict dirty 0x%08X\n", address);
                        writes++;
                    } else {
                        printf("Page fault - evict clean 0x%08X\n", address);
                    }

                    removeFromHashTable(&futureAccessTable, evict->counter);

                    queue->head = (queue->head + 1) % queue->size;
                    queue->tail = (queue->tail + 1) % queue->size;
                    queue->entries[queue->tail] = pte;

                    physicalMemory[evict->frame] = pte->counter;
                    pte->frame = evict->frame;
                    pte->validBit = 1;
                    evict->dirtyBit = 0;
                    evict->referenceBit = 0;
                    evict->validBit = 0;
                    evict->frame = -1;
                }
            }
        }
    }

    fclose(file);
    for(int i = 0; i < 512; i++){
	    if(root->pageTable[i] != NULL){
		    leaves++;
	    }
     }


     printf("Algorithm: Opt\n");
     printf("Number of frames: %d\n", numFrames);
     printf("Total memory access: %d\n", memAccesses);
     printf("Total page faults: %d\n", pageFaults);
     printf("Total writes to disk: %d\n", writes);
     printf("Number of page table leaves: %d\n", leaves);
     printf("Total size of page table: %d\n",(leaves * (sizeof(PageTableEntry) * 1024)) + sizeof(Root));
}
