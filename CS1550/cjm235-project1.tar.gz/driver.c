#include "graphics.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){
	//Initialize graphics
	init_graphics();

	//create an offscreen buffer
	void* offscreen_buffer = new_offscreen_buffer();

	if(offscreen_buffer == NULL){
		fprintf(stderr, "Failed to allocate offscreen buffer\n");
		exit(EXIT_FAILURE);
	}


	//main loop
	while (1){
		draw_line( offscreen_buffer, 100, 50, 200, 20, RGB(31, 00, 31));
		draw_line( offscreen_buffer, 10, 0, 10, 300, RGB(00, 63, 00));
		draw_line( offscreen_buffer, 0, 10, 300, 10, RGB(00, 00, 31));
		blit(offscreen_buffer);

		sleep_ms(3000);
		clear_screen(offscreen_buffer);
		draw_circle( offscreen_buffer, 200, 200, 94, RGB( 31, 31, 00));
		blit(offscreen_buffer);

		char key =  getkey();
		if( key != '\0') {

			if(key == 'q'){
				clear_screen(offscreen_buffer);
				blit(offscreen_buffer);
				break;
			}
		}

	}

	//cleam up and exit
	exit_graphics();

	return 0;
}
