#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_USERNAME_LEN 64
#define MAX_MSG_LEN 256

int send_msg(const char *to, const char *msg, const char *from){
	return syscall(441, to, msg, from);
}

int get_msg(const char *to, char *msg, char *from){
	return syscall(442, to, msg, from);
}

int main( int argc, char *argv[]){
	if(argc < 2) {
		printf("Usage: %s -s <recipient> <message> OR %s -r\n", argv[0]);
		return 1;
	}

	if(strcmp(argv[1], "-s") == 0 && argc == 4){
		const char *to = argv[2];
		const char *msg = argv[3];
		const char *from = getenv("USER");
		if(send_msg(to, msg, from) < 0){
			perror("Error sending message");
			return 1;
		}
		printf("message sent to %s: \"%s\"\n", to, msg);
	}else if(strcmp(argv[1], "-r") == 0 && argc == 2) {
		if(argc != 2){
			printf("Usage: %s -r\n",argv[0]);
			return 1;
		}

		const char *to = getenv("USER");
		char msg[MAX_MSG_LEN];
		char from[MAX_USERNAME_LEN];
		int result;
		do{
			result = get_msg(to,msg,from);
			if(result == 1){
				printf("%s said: \"%s\"\n", from, msg);
			}else if(result == 0){
				printf("No more messages for %s.\n", to);
			}else if (result == -1){
				printf("list is empty. \n");
			}else{
				perror("Error receiving messages");

			}
		}while(result == 1);
	}else{
		printf("Invalid option use -s to send or -r to receive messages.\n");
		return 1;
	}

	return 0;
}
