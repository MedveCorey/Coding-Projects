#include <stdio.h>
#include <stdlib.h>
#include "graphics.h"
#include <fcntl.h>
#include <unistd.h>
#include <linux/fb.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/select.h>
#include <time.h>
#include <string.h>
#include <termios.h>

typedef unsigned short color_t;

//global variables
int fbfd = -1;
struct fb_var_screeninfo vinfo;
struct fb_fix_screeninfo finfo;
void *fbp = NULL;
long screensize = 0;
struct termios originalTermios;

// initialize graphics library
void init_graphics(){

	//get the framebuffer information and initalize graphics
	fbfd = open("/dev/fb0", O_RDWR);
	if(fbfd == -1){
		perror("Unable to open framebuffer");
		exit(EXIT_FAILURE);
	}
	if(ioctl(fbfd, FBIOGET_FSCREENINFO, &finfo)){
		perror("Unable to get fixed screen information");
		close(fbfd);
		exit(EXIT_FAILURE);
	}
	if(ioctl(fbfd, FBIOGET_VSCREENINFO, &vinfo)){
		perror("Unable to get variable screen information");
		close(fbfd);
		exit(EXIT_FAILURE);
	}
	screensize = vinfo.yres_virtual * finfo.line_length;
	fbp = mmap(NULL, screensize, PROT_READ | PROT_WRITE, MAP_SHARED, 
	fbfd, 0);
	if((int)fbp == -1){
		perror("Unable to mmap framebuffer");
		close(fbfd);
		exit(EXIT_FAILURE);
	}

	//save the original terminal settings
	tcgetattr(STDIN_FILENO, &originalTermios);

	//Disable echo and icanon
	struct termios newTermios = originalTermios;
	newTermios.c_lflag &= ~(ICANON | ECHO);
	ioctl(fbfd, TCSETS, &newTermios);

}

//exit the graphics library
void exit_graphics() {
	//Restore the original terminal settings
	ioctl(fbfd, TCSETS, &originalTermios);

	//unmap the framebuffer and close the framebuffer device
	if (fbp != NULL){
		munmap(fbp, screensize);
		fbp = NULL;
	}
	if (fbfd != -1) {
		close(fbfd);
		fbfd = -1;
	}
}

//Get a key press
char getkey() {
	fd_set rfds;

	FD_ZERO(&rfds);
	FD_SET(0, &rfds);

	if (select(1, &rfds, NULL, NULL, NULL) > 0) {
		char input;
		if(read(0, &input, 1) == 1){
			return input;
		}
	}

	return '\0';

}

void sleep_ms(long ms){
	struct timespec req;
	//convert milliseconds to seconds
	req.tv_sec = ms / 1000;
	//convert milliseconds to nanoseconds
	req.tv_nsec = (ms % 1000) * 1000000;
	nanosleep(&req, NULL);
}

void clear_screen(void *img){
	unsigned char *ib = (unsigned char *)img;

	for (long i = 0; i < screensize; i++) {
		ib[i] = 0;
	}
}
void draw_pixel(void *img, int x, int y, color_t color){
	size_t offset = (y * vinfo.xres_virtual +x) *sizeof(color_t);
	color_t *fbp = (color_t *)img;

	fbp[offset / sizeof(color_t)] = color;
}

void draw_line(void *img, int x1, int y1, int x2, int y2, color_t color){
	int x = x1, y = y1;
	int dx = abs(x2 - x1);
	int dy = abs(y2 - y1);
	if(x2 < x1){
		int temp = x1;
		x1 = x2;
		x2 = temp;
	}
	if(y2 < y1){
		int temp = y1;
		y1 = y2;
		y2 =temp;
	}

	if(dx == 0){
		for(y = y1; y <= y2; y++){
			draw_pixel(img, x, y, color);
		}
	}else if(dy == 0){
		for(x = x1; x <= x2; x++){
			draw_pixel(img, x, y, color);
		}
	}else{

		/*bresenham's line algorithm adapted from https://www.geeksforgeeks.org/bresenham's-line-generation-algorithm*/
		int slope = 2 * dy;
		int slope_error = slope - dx;
		for (y = y1; y <= y2; y++){
			draw_pixel(img, x, y, color);
			slope_error += slope;

			if (slope_error >= 0) {
				x++;
				slope_error -= 2 *dx;
			}
		}
	}
}

void draw_circle(void *img, int x, int y, int r, color_t c){
	//midpoint circle algorithm adapted from https://www.geeksforgeeks.org/mid-point-circle-drawing-algorithm/
	int xc = 0, yc = r;
	int d = 3 -2 * r;
	while(yc >= xc){
		draw_pixel(img, x+xc, y+yc, c);
		draw_pixel(img, x-xc, y+yc, c);
		draw_pixel(img, x+xc, y-yc, c);
		draw_pixel(img, x-xc, y-yc, c);
		draw_pixel(img, x+yc, y+xc, c);
		draw_pixel(img, x-yc, y+xc, c);
		draw_pixel(img, x+yc, y-xc, c);
		draw_pixel(img, x-yc, y-xc, c);


		if(d > 0){
			yc--;
			d = d + 4 * (xc-yc) + 10;
		}else{
			d = d +4 * xc + 6;
		}
		xc++;
	}
}

void *new_offscreen_buffer(){
	void * buffer = (void *)mmap(NULL, screensize, PROT_READ |
	PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

	if(buffer == MAP_FAILED){
		perror("mmap offscreen buffer failed");
		exit(EXIT_FAILURE);
	}
	return buffer;
}

void blit(void *src){
	if(src == NULL){
		return;
	}

	//Pointer to start of the framebuffer
	unsigned char *fb = (unsigned char *)fbp;

	//pointer to start of the source buffer
	unsigned char *sb = (unsigned char *)src;

	for (size_t i = 0; i < screensize; i++){
		fb[i] = sb[i];
	}
}
